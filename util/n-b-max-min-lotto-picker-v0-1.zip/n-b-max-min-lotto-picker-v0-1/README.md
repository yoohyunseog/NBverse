# N/B MAX·MIN LOTTO PICKER v0.1

A Pen created on CodePen.

Original URL: [https://codepen.io/yoohyunserk/pen/PwZvEEm](https://codepen.io/yoohyunserk/pen/PwZvEEm).

